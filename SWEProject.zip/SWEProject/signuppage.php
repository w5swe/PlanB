
<!DOCTYPE html>
<html>
	<head>
	
	<link rel="stylesheet" href="hedfot.css">
		<link rel="stylesheet" href="homepage.css">
<script src="adminuserlogin.js"></script>
		 			  <link rel="stylesheet" href="Filter.css">
			  <link rel="stylesheet" href="Add&UpdateCake.css">
			   <script src="Filter.js"></script>
			  
		<title>signup Page</title>
	</head>
	<body>
	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
<!--	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> -->
	<ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li>Sign up page</li> 
       </ul>
	</header>
<main>
<div class="signup">
<div class="logIn">
    <form id="form" method="POST" action="registration.php">
<fieldset>
<legend>SIGN-UP</legend>
<label>First Name: <input type="text" name="Fname" placeholder="First Name"></label><br><br>
<label>Last Name: <input type="text" name="Lname" placeholder="Last Name"></label><br><br>
<label>username: <input type="text" name="username" placeholder="user name"></label><br><br>
<label>Password: <input type="password" name="Password" placeholder="Your Password" ></label><br><br>
<button type="submit" onclick="validationSign(); return false;">SIGN UP</button>
</fieldset>
</form>
</div>
	</div>
</main>





<footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
 
</footer>
  </body>
			</html>
			
                       