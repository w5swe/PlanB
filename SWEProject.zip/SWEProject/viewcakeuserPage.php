<?php
session_start();

$con = new PDO("mysql:host=localhost;dbname=Planb-2",'root','root');

if (isset($_POST["ssubmit"])) {
	$str = $_POST["ssearch"];
	$sth = $con->prepare("SELECT * FROM `cake_shop` WHERE cake_shop_name = '$str'");

	$sth->setFetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();
        
        if($row = $sth->fetch())
	{
          $name = $row->name ;
          $des= $row->description;
          $logo = $row->logo_pic;
          $userid=$row->id;
          
	}	
		else{
			echo "<script>alert('Sorry this cake shop is not avaliable!!'); window.location.href='viewcakeuserPage.php';</script>";
		}


}
 
?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="hedfot.css">
<script src="Filter.js"></script>
<script src="Add&UpdateCake.js"></script>
<link rel="stylesheet" href="Filter.css">
<link rel="stylesheet" href="Add&UpdateCake.css">

<script src="raterecommended.js"></script>

<title>View Cake Page User</title>
</head>
<body>
<?php include "connection.php"; ?>
<header class="hed">
<span><img src="images/logo.png" alt="logo" id="logo" width="200" height="200"></span>
<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span>


 <ul class="breadcrumb" id="hbc">
<li><a href="homepage.php">Home</a></li>
<li><a href="userlogin.php"> Login</a></li>
<li>View Cake Shops</li>
</ul>
</header>
<form method="post" action="">
<aside id="filters">
<h1 class="bigHead" id="titles">FILTER CAKE STORES</h1>
<h2 class="bump" id="h2Filter" ><span class="results" id="numOfResults"></span> cake stores Found</h2>
<div id="CakeType">
<h1 id="titles">Cake Type</h1>
<div class="bump">
<div class="box1">
<input type="checkbox" name="caketype[]" value="Vegetarians" id="Vegetarians" calss="choosedCakeType">
<label for="Vegetarians" class="check-box"></label>
<h4>Vegetarians</h4>
</div>
<div class="box1">
<input type="checkbox" name="caketype[]" value="Diabetics" id="Diabetics" calss="choosedCakeType">
<label for="Diabetics" class="check-box"></label>
<h4>Diabetics</h4>
</div>
<div class="box1">
<input type="checkbox" name="caketype[]" value="Allergic" id="Allergic" calss="choosedCakeType">
<label for="Allergic" class="check-box"></label>
<h4>Allergic</h4>
</div>
<div class="box1">
<input type="checkbox" name="caketype[]" value="Healthy" id="Healthy" calss="choosedCakeType">
<label for="Healthy" class="check-box"></label>
<h4>Healthy</h4>
</div>
<div class="box1">
<input type="checkbox" name="caketype[]" value="All" id="All" calss="choosedCakeType">
<label for="All" class="check-box"></label>
<h4>All</h4>
</div>
</div>
<br>
<input type="submit" name="filter" value="Filter" id="submit" >
</div>
</aside>
</form>

 <form method="post" >
    <label><img src="images/search.png" alt="search" id="search_icon"></label>
<input type="text" name="ssearch" id="searchtext" placeholder="What are you looking for?">
<input type="submit" name="ssubmit" value="SEARCH" id="Sbutton">
</form>

    
    
    
              
    <div class="searchshop-thumb"><img src="logo/<?php echo "$logo"; ?>" /></div> 
 <div class="searchshop-content">
     <div class="searchshop-title"> 
        <?php echo $row->cake_shop_name ; ?>
     </div><br><br>
        <?php echo $row->description ; ?>
     <br><br><br><br>
      <?php echo "<tr><a href='reviews.php?shop_id_ForViUser=".$userid."' id=\"view1\" >". "view</a></tr><br><br>"; ?>
    </div>
    
    
    
 <div class="recommanded">
<div class="area">
<div class="good"><span>BEST CHOICE</span></div>
  <?php 

    $sqlre='SELECT * FROM cake_shop WHERE prate=(SELECT MAX(prate) FROM cake_shop)';
    $result= mysqli_query($connection, $sqlre);
    while($rowb =mysqli_fetch_assoc($result)){
  
    $logo=$rowb['logo_pic'];

?>
<img src="logo/<?php echo "$logo";?>" alt="recommanded" id="best" >
<br>
<p id="cakename">By <?php echo $rowb['cake_shop_name'];?> cake shop</p>
<br>
<br>


</div>
	</div>
        
            <?php
}
?>  
    
    
    
    <div id="cakeTable">
        <table>
        
  <?php  
                $sql = "SELECT logo_pic ,cake_shop_name,id FROM cake_shop";
                $result = mysqli_query($connection, $sql);

      while($row1=  mysqli_fetch_array($result)) {

            echo 
              "<tr><img class=\"img1\" src=\"logo/".$row1['logo_pic'].'" ></tr>'.
              "<tr><h2><nav class=\"shopname1\">".$row1['cake_shop_name']."</nav></h2></tr><br><br><br>".
              "<tr><a href='reviews.php?shop_id_ForViUser=".$row1['id']."' id=\"view1\" >". "view</a></tr><br><br><br><br>"; 
          }?>
      
    </table>
    </div>

    
<?php

$counter=0;

if(isset($_POST['filter'])){


 if(!empty($_POST['caketype'])) {
echo '<script> document.getElementById("cakeTable").style.visibility = "hidden";</script>';
foreach($_POST['caketype'] as $value){
$cake_typeID;

if($value == "Vegetarians")
{
$cake_typeID=1;
}
else
if($value == "Diabetics")
{
$cake_typeID=2;
}
else
if($value == "Allergic")
{
$cake_typeID=3;
}
else
if($value == "Healthy")
{
$cake_typeID=4;
}
else
if($value == "All")
{
$cake_typeID=5;
}
if($cake_typeID == 5)
{
$sql1="SELECT * FROM cake_shop";
$result1= mysqli_query($connection, $sql1);
}
else
{
$sql1="SELECT * FROM cake_shop WHERE cake_type=$cake_typeID";
$result1= mysqli_query($connection, $sql1);
}

while($row1 = mysqli_fetch_assoc($result1))
{
echo '<div id="cakeshopFilter">';
echo '<table>';
echo
"<tr><img class=\"img1\" src=\"logo/".$row1['logo_pic'].'" ></tr>'.
 "<tr><h2><nav class=\"shopname1\">".$row1['cake_shop_name']."</nav></h2></tr><br><br><br>";

 echo"<tr><a href='reviews.php?shop_id_ForViUser=".$row1['id']."' id=\"view1\" >". "view</a></tr><br><br><br><br>";
echo "</table>";
$counter= $counter+1;
echo "</div>";

}

}

}
echo '<script> document.getElementById("numOfResults").innerHTML="'.$counter.'";</script>';
}
?>

<footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
</footer>

 </body>
</html>