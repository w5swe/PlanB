<?php 
session_start();

?>
<!DOCTYPE html>
<html>
	<head>
	<link rel="stylesheet" href="hedfot.css">
		<link rel="stylesheet" href="homepage.css">
		 <script src="adminuserlogin.js"></script>
		 			  <link rel="stylesheet" href="Filter.css">
			  <link rel="stylesheet" href="Add&UpdateCake.css">
		<title>adminloginpage </title>
	</head>
	<body>
            
              <?php include "connection.php"; ?>
            
	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
<!--	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span>-->
	  	<ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li>Admin login page</li> 
	</header>
	
<main>

	

<div class="logIn">
<form  id="form" method="POST" action="">
<fieldset>
<legend>AdminLog-in</legend>

<p>Username:</p>

<label>
<input name="Mname" type="text" placeholder="Name">
</label>

<p>Password: </p>

<label>
<input name="password" type="password" placeholder="password">
</label>

<button type="submit" name="submit" onclick="return validateaLogInAdmin();" >log-in</button> 


 </fieldset>
</form>
 
    <?php
    if(isset($_POST['submit'])){
   
  
           
    $username= $_POST['Mname'];
    $password=$_POST['password'];
    
    $sql1=" SELECT * FROM admin WHERE user_name='$username' AND password ='$password'";
            
    $result= mysqli_query($connection, $sql1);
    
    
    
    if (!mysqli_fetch_array($result))
    { 
        echo ' <script> alert("sorry the user name or password is wrong"); </script>';
   
    }
    
    else 
    {  
      
     echo '<script> location.replace("ViewCakeAdminPage.php"); </script>'; 
         
    }
    
    
    
    }
    
    
    ?>
</div>

</main>





<footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
 
</footer>

			</body>
			</html>
			
			