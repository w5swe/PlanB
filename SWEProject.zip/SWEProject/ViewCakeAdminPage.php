<?php
session_start();


 
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="hedfot.css">
        <script src="Filter.js"></script> 
        <script src="Add&UpdateCake.js"></script>
        <link rel="stylesheet" href="Filter.css">
        <link rel="stylesheet" href="Add&UpdateCake.css">
		
		<title>ViewCakePageAdmin</title>
	</head>
	<body>

              <?php include "connection.php"; ?>
            
            
	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> 

    <ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="adminlogin.php"> Login Admin</a></li>
        <li>View Cake Shops</li> 
       </ul>
 
	</header>

<main>
    <br>
    <input type="submit" value="Add Cake" id="add" onclick=" goToAdd(); return false">
    <div id="cakeTable">
  
    <table>
        
  <?php  
                $sql = "SELECT logo_pic ,cake_shop_name ,id FROM cake_shop";
                $result = mysqli_query($connection, $sql);
                
   
       
      while($row=  mysqli_fetch_array($result)) {
            
            echo 
              "<tr><img class=\"img1\" src=\"logo/".$row['logo_pic'].'" ></tr>'.
            "<tr><h2><nav class=\"shopname1\">".$row['cake_shop_name']."</nav></h2></tr><br><br><br><br>".
              "<tr>";
       echo   "<a href='UpdateCakePage.php?shop_id_ForUp=".$row['id']."'id=\"UpdateCake1\">". "Update</a>";
       echo   "<a href='DeleteCakePage.php?shop_id_ForDE=".$row['id']."'id=\"DeleteCake1\">". "Delete</a>";
       echo   "<a href='adminreviews.php?shop_id_ForVi=".$row['id']."'id=\"viewadmin1\">". "view</a></tr><br><br><br>";
  
       


          }
          
          
          
          ?>
    </table>
    </div>
    
    
	

      

</main>




    



<footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
 
</footer>

			</body>
			</html>
			
			
