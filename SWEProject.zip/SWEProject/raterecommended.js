function rate()
{
	alert("Thank you for rating us , you are helping us to improve our products ");
        //window.location.href="reviews.php";
        location.reload("reviews.php");
}


function view()
{
	location.replace("reviews.php"); 
}

