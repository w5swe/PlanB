<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="refresh" content="10" >

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>reviews</title>
       
         <link rel="stylesheet" href="hedfot.css">
             <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
			 <link rel="stylesheet" href="homepage.css">
	        <script src="raterecommended.js"></script>
            <link rel="stylesheet" href="reviews.css">
			  <link rel="stylesheet" href="Filter.css">
			  <link rel="stylesheet" href="Add&UpdateCake.css">
<!--            <script src="valid.js"></script>-->
                          
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    </head>
    <body>
                    <script>
   
$(document).ready(function(){
  $(".nrate").click(function(currentId){

      var rateid = currentId.currentTarget.id;


$.ajax({
     
    type: 'GET',
    url: 'incremntnrate.php',
    data: 'id='+rateid,
    success: function(){
       
    }
    });
  });
}); 

</script>
  <script>

$(document).ready(function(){
  $(".prate").click(function(currentId){

      var rateid = currentId.currentTarget.id;


$.ajax({
     
    type: 'GET',
    url: 'incremntprate.php',
    data: 'id='+rateid,
    success: function(){
       
    }
    });
  });
}); 

</script>
<?php 
session_start();

?>
              <?php

  include "connection.php";

?>
        	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> 
		<ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="userlogin.php"> Login</a></li>
				 <li><a href="viewcakeuserPage.php">view cake </a></li>
        <li>review Cake Shops</li> 
       </ul>
	</header>
<section class="review" id="review">

<?php
$cakeid=$_GET['shop_id_ForViUser'];



$sql="SELECT description , logo_pic ,cake_shop_name FROM cake_shop WHERE id='$cakeid'";
$result = mysqli_query($connection, $sql);

if($rows=mysqli_fetch_assoc($result))
{
    
$logo=$rows['logo_pic'];  
$description=$rows['description'];
$cakename=$rows['cake_shop_name'];

}

?>
<div class="post-container">                
    <div class="post-thumb"><img src="logo/<?php echo "$logo"; ?>" /></div>
    <div class="post-content">
        <h3 class="post-title"><?php echo "$cakename"; ?> </h3>
        <p> <?php echo "$description"; ?></p>

        
   </div>
       <div>
           <br>
<?php echo '<div class="rate">';?>
           <?php 

//$cakeid=4;
           $ratesql = "SELECT * FROM cake_shop WHERE id='$cakeid'";
           $rateresult = mysqli_query($connection, $ratesql);
           while($row = mysqli_fetch_assoc($rateresult))
           {
           ?>
<?php echo '<span class ="numrate">' .$row['nrate']. '</span>' ;?>
<?php echo '<button class="ratebutton" type="submit" onclick="rate(); return false;" >'.'<a href ="" class="nrate" id='.$row['id'].'>'.'<img src="images/negative-rate.png" alt="negative-rate" id="nrate"  width="200" height="200" >'.'</a>'.'</button>' ;?>
<?php echo '<span class ="numrate">' .$row['prate']. '</span>' ;?>
<?php echo '<button class="ratebutton" onclick="rate(); return false;" >'.'<a href ="" class="prate" id='.$row['id'].'>'.'<img src="images/positive-rate.png" alt="positive-rate" id="prate"  width="200" height="200">'.'</a>'.'</button>' ;?>

    
  
<?php echo'</div>';?>
           
    </div>
    <?php 
    
        }
           
           ?>
</div>

</section>

    <div class="container">
        <div class="board">
            <h2 class="text-light">Word form our customers</h2>
            <p class="text-light">Some of the fullfilled costomers reviews</p>

            <!-- Slider main container -->
            <div class="swiper">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                <!-- Slides -->
                     <?php
         
            //$cakeid=4;           
          $sql2="SELECT username , comment  FROM review WHERE cakeshopID='$cakeid'";
          $result2 = mysqli_query($connection, $sql2);

          while($rows2=mysqli_fetch_assoc($result2))
          {
         
          

     echo'
                <div class="swiper-slide">
                    <div class="flex">
                        <div class="comments">'.
                            $rows2['comment'].'
                        </div>
                      <div class="profile">
                            
                            <p>'.$rows2['username'].'</p>
                            
                        </div>
                    </div>
                </div>';
          }
?>
 
                </div>
                <!-- If we need pagination -->
                <div class="swiper-pagination"></div>
            
                <!-- If we need navigation buttons -->
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
        
            </div>

        </div>
    </div>

    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
    <script src="./main.js"></script>
              <section class="revieww">
                  <form class="fo" id="reviews" name="reviews" method="post">
                <fieldset id="fieldset" class="fieldset">
                      <legend id="fieldset" class="fieldset">add Review</legend>
                  <label for="reviews"></label> <br>
            <textarea id="rev" name="review" rows="10" cols="50" maxlength="300"></textarea>
            <br>
            <input type="submit" value="addReview" id="send" onclick="return validateTextArea()">
             </fieldset>
            </form>  
            
            
        </section>
      <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $userid=$_SESSION['userID'];
      echo $userid;
                    $sql4="SELECT user_name   FROM user WHERE id='$userid'";
          $result4 = mysqli_query($connection, $sql4);

          if($rows4=mysqli_fetch_assoc($result4))
          {
              $username=$rows4['user_name']; 
             // $username="Alanoud";
          }
           //it must be sent to me
            $cakeID=$_GET['shop_id_ForViUser'];
$comment=$_POST['review'];

  $sql3= "INSERT INTO review (userID, cakeshopID, username,comment )  VALUES ('$userid','$cakeID','$username','$comment')";
  $add=mysqli_query($connection, $sql3);

  if(!$add){
    echo "data not inserted" . mysqli_error($connection);

  }
  else {

       echo "<script>location.replace('viewcakeuserPage.php');</script>";

  }

  }

  ?> 
        
        <footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
 
</footer>
    

            <script>
            function validateTextArea() {


             let textareaCheck = document.getElementById("rev").value;

      if (textareaCheck == "") {
        alert("please write review");
      return false;
      }

            }
    


   
            </script>
    </body>
</html>