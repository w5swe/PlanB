
function redirectToAddCakePage() {

   if( validateAttachment()==true && validateTextArea()==true && validateText()==true ){
    alert("cake store is added")
    location.replace("ViewCakeAdminPage.php");
   }
  }

  
  
    function validateAttachment(){

      let attachmentCheck= document.forms["AddCakeForm"]["attachment"].files.length;

      if (attachmentCheck > 1) {
        alert("please you can not upload more than 1 logo");
      return false;
    }
    else
    return true;
    }
    

    function validateTextArea(){

      let textareaCheck = document.getElementById("Dis").value;

      if (textareaCheck == "") {
        alert("please write short disruption");
      return false;
      }
      else
      return true;
    
    }
   

    function validateText(){

      let textCheck = document.forms["AddCakeForm"]["cakename"].value;

      if (textCheck == "") {
        alert("please Enter the store's name");
      return false;
      }
      else
      return true;
    
    }

    function deleteCakeStore()
    {
     if(confirm("Are you sure you want to delete this Cake Store!?"))
     {
      location.replace("ViewCakeAdminPage.php");
     }
     else
     {
      location.replace("DeleteCakePage.php");
     }
    }

    /*buttons in view cake shop*/
    function goToDelete()
    {
     
      location.replace("DeleteCakePage.php");
    }

 function GoToUpdate()
    {
      location.replace("UpdateCakePage.php");
    }

function redirectToDeleteAndUpdate()
{
  alert("it will redirect to the approprite page when using php");
}

function goToAdd()
{
  location.replace("AddCakePage.php");
}



function goToadminreview()
{
  location.replace("adminreviews.php");
}    

    


