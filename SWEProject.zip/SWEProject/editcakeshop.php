<?php
session_start();
include "connection.php";


        $id=$_SESSION['id'];
      
        
       if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] == "POST"){
         $cakename=$_POST['cakename'];
         $Discription=$_POST['Discription'];
         $attachment=$_POST['attachment'];
         $type;
         
         if ($_POST['type']=='Vegetarians'){
              $type=1;
         }
         else
         if($_POST['type']=='Diabetics'){
              $type=2;
         }
         else
         if($_POST['type']=='Allergic'){
              $type=3;
         }
          else
         if($_POST['type']=='Healthy'){
              $type=4;
         }
       }
        
       $sql = "UPDATE cake_shop SET cake_shop_name='".$cakename."' , description= '".$Discription."' , logo_pic='".$attachment."' , cake_type='".$type."' WHERE id=$id";
         
        
         if ($connection->query($sql) === TRUE) {
        
         echo '<script>alert("cakeshop updated")</script>';
        
         echo '<script> window.location.replace("ViewCakeAdminPage.php")</script>';
         } 
         
         else {
            //echo "Error updating record: " . $connection->error;
        echo '<script>alert("can not update the cakeshop")</script>';
       
         } 
        
        
        
?>