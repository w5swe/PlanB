

 <?php include "connection.php"; ?>

<?php

    if(isset($_POST['Mname']) && isset($_POST['password']))
    {
        $id = $_POST['Mname'];

        $pass =$_POST['password'];
        
      
        
        


        $query = "SELECT * FROM user WHERE user_name = '$id' AND password = '$pass'";
 

        $result =  mysqli_query($conn ,$query);

      

        session_start();
        
        if( ($row = mysqli_fetch_row($result)) > 0){

            $re = mysqli_query($conn , $query);

            $result2 = mysqli_fetch_assoc($re);
       
        // $_SESSION['user'] = $result2['id'];
 
         $_SESSION['userID']= $result2['id'];
         $_SESSION["role"]= 'user';

       
         //header("location:viewcakeuserPage.php"); 
         echo "<script> window.location.href='../viewcakeuserPage.php';</script>";
        }
         else
        {
              
            echo "<script> window.location.href='userlogin.php';</script>";
            //header("location:./employeelogin.php");
           //. "window.location.href='./employeelogin.php';
        
            
        }
    }





?>