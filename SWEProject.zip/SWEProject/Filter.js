



function viewshop()
{
	

  location.replace("reviews.php");


}




     
