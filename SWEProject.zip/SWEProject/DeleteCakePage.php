<?php 
session_start();

?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="hedfot.css">
        <link rel="stylesheet" href="Add&UpdateCake.css">
        <script src="Add&UpdateCake.js"> </script>
        

		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Delete Cake Store </title>
	</head>
	<body>
            
            <?php include "connection.php"; ?>
            
	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> 
    
    <ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="adminlogin.php"> Login</a></li>
        <li><a href="ViewCakeAdminPage.php"> View Cake Shops</a></li>
        <li>Delete Cake Shop</li> 
       </ul>
    
	</header>
<main>

    
<div id="bakeryInfo"> 
    <br><br>



 <?php 
         echo '<form id="delForm" method="POST">';
        //i have to fix the session and logo pic 
          
        $shop_id=$_GET['shop_id_ForDE'];
        
 
        $sql1="SELECT * FROM cake_shop WHERE id='$shop_id'";
        $result= mysqli_query($connection, $sql1);
        
        $cake_type;
              
         while($row = mysqli_fetch_assoc($result))
         {
             if($row['cake_type']==1) 
                 {
                     
                     $cake_type="Vegetarians";
                 }
                 else 
                    if($row['cake_type']==2) 
                 {
                     
                     $cake_type="Diabetics";
                 }
                 else
                     if($row['cake_type']==3) 
                 {
                     
                     $cake_type="Allergic";
                 }
                 else
                     if($row['cake_type']==4) 
                 {
                     
                     $cake_type="Healthy";
                 }
                  echo '<img src="logo/'.$row['logo_pic'].'" id="munchLogo">';
                          
                  echo '<h2 id="title">'.$row['cake_shop_name'].' </h2> <br>';
                  echo '<p id="pargraph">'. 
                        $row['description'].'.<br>'.'cake type: #'.$cake_type
                        .'</p>';
                  
      
                  echo '<input type="submit" name="Delete" id="Delete" value="Delete" >';
                  // echo "<td><a id=\"Delete\" name=\"Delete\" onClick=\"javascript: return confirm('are yue sure you want to delete the cake shop?');\" href=\"?link1\">Delete</a></td><tr>"; 
                        
                          
                      
                  echo '<br><br>';   
                  
                 
                  
         }
         
         
         if(isset($_POST['Delete']))
         {
       
             
             $sql2 = "DELETE FROM cake_shop WHERE id='$shop_id'";
         
                    if ($connection->query($sql2) === TRUE) 
                    {
                         echo "<script>" ;//language='javascript'>";
                         echo 'alert("cake shop is deleted successfully");';
                         echo 'window.location.replace("ViewCakeAdminPage.php");';
                         echo "</script>";
                       
                          
                     }
                   else
                   {
                           echo '<script> alert("Error deleting cake shop:")</script>';
                   }
         }
         
            echo '</form>';

                  
?>

</div>
  
   
    </main>

			
    <footer id="foot">
        <p>For Technical Problems please Contact us:</p>
        
        <pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany
        
        &copy; PLanB</pre>
         
        </footer>
        
                    </body>
                    </html>