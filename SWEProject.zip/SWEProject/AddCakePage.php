<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="hedfot.css">
        <link rel="stylesheet" href="Add&UpdateCake.css">
<!--  <script src= "Add&UpdateCake.js"></script>-->

		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Add Cake Store </title>
	</head>
	<body>
              <?php

  include "connection.php";

?>
	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> 
 
    <ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="adminlogin.php"> Login</a></li>
        <li><a href="ViewCakeAdminPage.php"> View Cake Shops</a></li>
        <li>Add Cake Shop</li> 
       </ul>
  
	</header>
<main>


    <form id="AddCakeForm" name="AddCakeForm" enctype="multipart/form-data"  method="post">
        <fieldset id="fieldset">
         <legend>Add new cake store</legend>
            <br>
            <label for="cakename">Cake Store Name:</label>
            <input type="text" id ="cakename" name="cakename"><br><br>
            
             <label for="serivce">Cake Type:</label><br>

            <input type="radio" id="T1" name="type" value="1" checked>
            <label for="ser1">Vegetarians</label><br>
			
            <input type="radio" id="T2" name="type" value="2">
            <label for="ser2">Diabetics</label><br>  
            <input type="radio" id="T3" name="type" value="3">
            <label for="ser3">Allergic</label><br>
            <input type="radio" id="T4" name="type" value="4">
            <label for="ser4">Healthy</label><br><br>
            
            <label for="Discription">Add Discription </label> <br>
            <textarea id="Dis" name="Discription" rows="10" cols="50" maxlength="300"></textarea> <br><br>

             <label for="attachment">Select the  store's logo:</label>
             <input type="file" id="attach" name="attachment" class="custom-file-input" multiple><br><br>

             <input type="submit" value="submit" id="send"  onclick="return redirectToAddCakePage()">
            
        </fieldset>
       </form>

    </main>
  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      

  

  
$cakename=$_POST['cakename'];
$type=$_POST['type'];
$Discription=$_POST['Discription'];

$attachment11=$_FILES['attachment']['name'];


$attachment1=$_FILES['attachment']['tmp_name'];

$attachment="logo/";

$upload1= move_uploaded_file($attachment1,$attachment.$attachment11);







$sql1 = "Select * FROM cake_shop ;";
$result = mysqli_query($connection, $sql1);

$insert=true;
while ($row = mysqli_fetch_assoc($result)) {
    $cakeArray[]= $row;
    if($row["cake_shop_name"]==$cakename)
        $insert=false;
}
  
if($insert)
{
 
  $sql= "INSERT INTO cake_shop (cake_shop_name, description, logo_pic,cake_type,prate,nrate )  VALUES ('$cakename','$Discription','$attachment11','$type','0','0')";
  $add=mysqli_query($connection, $sql);

  if(!$add){
    echo "data not inserted" . mysqli_error($connection);

  }
  else {
          $idcakeshop=Mysqli_insert_id($connection); 

       echo "<script>window.location.href='ViewCakeAdminPage.php'</script>";

  }

}
  
 else {
   echo "<script>alert('sorry the shop is already exists ‎')</script>";
} 
  
  }

  ?>
			
    <footer id="foot">
        <p>For Technical Problems please Contact us:</p>
        
        <pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany
        
        &copy; PLanB</pre>
         
        </footer>
        <script>
            function redirectToAddCakePage() {




  
        let textCheck = document.forms["AddCakeForm"]["cakename"].value;

      if (textCheck == "") {
        alert("please Enter the store's name");
      return false;
      }
             let textareaCheck = document.getElementById("Dis").value;

      if (textareaCheck == "") {
        alert("please write short disruption");
      return false;
      }
            let attachmentCheck= document.forms["AddCakeForm"]["attachment"].files.length;

      if (attachmentCheck > 1) {
        alert("please you can not upload more than 1 logo");
      return false;
  
  }
  
        if (document.getElementById("attach").value=="") {
        alert("please you must choose logo");
      return false;
  
  }
      
       
            }
    


   
            </script>
                    </body>
                    </html>