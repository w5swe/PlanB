<?php
 include "connection.php";
        $error = mysqli_connect_error();
        if ($error != null) {
            $output= '<p> Could not connect to the database. </p>'.$error;
            exit($output);
  
            }
            $id=$_GET['id'];
                   $sqlrate = "UPDATE cake_shop SET nrate=nrate+1 WHERE id='$id'";
                   if(mysqli_query($connection, $sqlrate)){
                  echo '<script>window.location.href="reviews.php";</script>';
                  }
               else 
               {
                   echo 'failed increment rate'. mysqli_error($connection,$sqlrate)  ;
                }
            
            
            
            
?>