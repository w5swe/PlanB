
		 
	 
		 function validateTextArea(){
	 
		   let textareaCheck = document.getElementById("rev").value;
	 
		   if (textareaCheck == "") 
			 alert("please write review");

		 
		 }
		
	 

 
