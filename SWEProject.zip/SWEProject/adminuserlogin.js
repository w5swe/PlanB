
 //sign up validation
      function validationSign() {

      if( validateNames()== true && validateMPassowrd()== true && validateUserName()==true ){
	  location.href='userlogin.php'; 
      }
     }

     
     function validateNames(){
 
      let firstName= document.forms["form"]["Fname"].value;
      let LasttName= document.forms["form"]["Lname"].value;
    

      if (firstName == "") {
        alert("please you must fill the first name ");
      return false;
    }

    if(!/^[a-zA-Z]*$/g.test(firstName))
    {
       alert("please you must enter charachters only");
     return false;
   }

   if (LasttName == "") {
    alert("please you must fill the last name ");
  return false;
}

if(!/^[a-zA-Z]*$/g.test(LasttName))
{
   alert("please you must enter charachters only");
 return false;
}

    
    return true;
 }
	
	
	
function ulogin()
{
location.replace("userlogin.php"); 	
}




function alogin()
{
location.replace("adminlogin.php"); 	
}

//validate log in for user and admin

 function validateaLogInAdmin() {

    if(validateUserName()==true && validateMPassowrd()== true){
     location.replace("adminlogin.php");
    }
   }
   
   function validateuLogInUser() {

    if(validateUserName()==true && validateMPassowrd()== true){
     location.replace("userlogin.php");
    }
   }
   
function validateUserName(){
 
       let MUserName= document.forms["form"]["Mname"].value;
 
       if (MUserName == "") {
         alert("please you must fill the UserName");
         return false;
     }
    else
    return true;
    
  }
    function validateMPassowrd(){
 
      let Mpassword= document.forms["form"]["password"].value;

      if (Mpassword == " ") {
        alert("please you must fill the Password");
        return false;
    }

    if(/\D/.test(Mpassword))
    {
       alert("please you must enter numbers only");
     return false;
   }

   else
   return true;
   
 }
 