<?php 


if(isset($_POST['Fname']) && isset($_POST['Lname']) && isset($_POST['username']) && isset($_POST['Password']) )
{
    $conn  = mysqli_connect("localhost", "root", "root", "Planb-2");
        $error = mysqli_connect_error();
        if ($error != null) {
            $output= '<p> Could not connect to the database. </p>'.$error;
            exit($output);
        }
   $sql1 = "SELECT user_name FROM user WHERE user_name = '".$_POST['username']."'";
   $res = mysqli_query($conn , $sql1);
   if($row=  mysqli_fetch_array($res)) {
       echo "<script> alert('The username is already exists'); window.location.href='signuppage.php'; </script>";
   }
    else{   
 
  echo  $fname = $_POST['Fname'];

  echo  $lname = $_POST['Lname'];
    
  echo  $username = $_POST['username'];

  echo  $pass = $_POST['Password'];
  
 
    $query = "INSERT INTO user ( first_name , last_name , user_name , password) 
    VALUES ('$fname' ,'$lname' ,'$username' ,'$pass')";

    $result = mysqli_query($conn , $query);

    if($result) header("location:userlogin.php");

    else { echo "<script> alert('please you have to fill correctly'); window.location.href='signuppage.php'; </script>";
          
       
    }
}

    }



?>