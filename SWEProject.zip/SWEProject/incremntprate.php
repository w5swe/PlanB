<?php
  include "connection.php";
        if ($error != null) {
            $output= '<p> Could not connect to the database. </p>'.$error;
            exit($output);
  
            }
            $id=$_GET['id'];
                   $sqlrate = "UPDATE cake_shop SET prate=prate+1 WHERE id='$id'";
                   if(mysqli_query($connection, $sqlrate))
                    
                     echo '<script>window.location="reviews.php"</script>'; 
               else 
               {
                   echo 'failed increment rate'. mysqli_error($connection,$sqldecline)  ;
                }
            
            
            
            
?>