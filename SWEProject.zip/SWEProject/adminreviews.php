<?php 
session_start();

?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>adminreviews</title>
       
         <link rel="stylesheet" href="hedfot.css">
             <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
			 <link rel="stylesheet" href="homepage.css">
	        <script src="raterecommended.js"></script>
            <link rel="stylesheet" href="reviews.css">
			  <link rel="stylesheet" href="Filter.css">
			  <link rel="stylesheet" href="Add&UpdateCake.css">
            <script src="valid.js"></script>
			
    </head>
    <body>
        
                   <?php

  include "connection.php";

?>
        	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> 
		<ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="adminlogin.php"> Login</a></li>
		 <li><a href="ViewCakeAdminPage.php">view cake admin </a></li>
        <li>review Cake Shops</li> 
       </ul>
	</header>
<section class="review" id="review">
<?php
$id=$_GET['shop_id_ForVi'];
$sql="SELECT description , logo_pic ,cake_shop_name FROM cake_shop WHERE id=$id";
$result = mysqli_query($connection, $sql);

if($rows=mysqli_fetch_assoc($result))
{
$logo=$rows['logo_pic'];  
$description=$rows['description'];
$cakename=$rows['cake_shop_name'];
}

?>

<div class="post-container">                
    <div class="post-thumb"><img src="logo/<?php echo "$logo"; ?>" /></div>
    <div class="post-content">
        <h3 class="post-title"><?php echo "$cakename"; ?> </h3>
        <p> <?php echo "$description"; ?></p>


        
   </div>
       <div>
           <br>

    </div>
</div>

</section>
        

    <div class="container">
        <div class="board">
            <h2 class="text-light">Word form our customers</h2>
            <p class="text-light">Some of the fullfilled costomers reviews</p>

            <!-- Slider main container -->
            <div class="swiper">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                <!-- Slides -->
                 <?php
          $sql2="SELECT username , comment  FROM review WHERE cakeshopID='$id'";
          $result2 = mysqli_query($connection, $sql2);

          while($rows2=mysqli_fetch_assoc($result2))
          {
         
          

     echo'
                <div class="swiper-slide">
                    <div class="flex">
                        <div class="comments">'.
                            $rows2['comment'].'
                        </div>
                      <div class="profile">
                            
                            <p>'.$rows2['username'].'</p>
                            
                        </div>
                    </div>
                </div>';
          }
?>
                
               
                </div>
                <!-- If we need pagination -->
                <div class="swiper-pagination"></div>
            
                <!-- If we need navigation buttons -->
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
        
            </div>

        </div>
    </div>

<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
    <script src="./main.js"></script>
        
      <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
       // $userid=$_SESSION['userID'];
          $userid=1;
                    $sql4="SELECT user_name   FROM user WHERE id='$userid'";
          $result4 = mysqli_query($connection, $sql4);

          if($rows4=mysqli_fetch_assoc($result4))
          {
              $username=$rows4['user_name']; 
              //$username="Alanoud";
          }
          
           
$comment=$_POST['review'];

  $sql3= "INSERT INTO review (userID, cakeshopID, username,comment )  VALUES ('$userid','$id','$username','$comment')";
  $add=mysqli_query($connection, $sql3);

  if(!$add){
    echo "data not inserted" . mysqli_error($connection);

  }
  else {

       echo "<script>window.location.href='reviews.php'</script>";

  }

  }

  ?> 
        
        <footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
 
</footer>
  <script>
            function validateTextArea() {


             let textareaCheck = document.getElementById("rev").value;

      if (textareaCheck == "") {
        alert("please write review");
      return false;
      }

            }
    


   
            </script>
    </body>
</html>