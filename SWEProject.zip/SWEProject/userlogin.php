<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="hedfot.css">
<link rel="stylesheet" href="homepage.css">
<script src="adminuserlogin.js"></script>
<link rel="stylesheet" href="Filter.css">
<link rel="stylesheet" href="Add&UpdateCake.css">
<title>userloginpage</title>
</head>
<body>
<?php include "connection.php"; ?>
<header class="hed">
<span><img src="images/logo.png" alt="logo" id="logo" width="200" height="200"></span>
<!--<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span>-->
<ul class="breadcrumb" id="hbc">
<li><a href="homepage.php">Home</a></li>
<li>User login page</li>
</header>
<main>


<div class="logIn">
<form method="POST" id="form" action="">
<fieldset>
<legend>UserLog-in</legend>

<p>Username:</p>

<label>
<input name="Mname" type="text" placeholder="Name">
</label>

<p>Password: </p>

<label>
<input name="password" type="password" placeholder="password">
</label>

<button type="submit" name="submit" onclick="validateuLogInUser();" >log-in</button>

</fieldset>
</form>
<?php
if(isset($_POST['submit'])){

$username= $_POST['Mname'];
$password=$_POST['password'];
$sql1=" SELECT * FROM user WHERE user_name='$username' AND password ='$password'";
$result= mysqli_query($connection, $sql1);

session_start();


 if( ($row = mysqli_fetch_row($result)) > 0)
{
$re = mysqli_query($connection , $sql1);

 $result2 = mysqli_fetch_assoc($re);
$_SESSION['user'] = $result2['id'] ;
$_SESSION['userID']= $result2['id'];

echo '<script> location.replace("viewcakeuserPage.php"); </script>';
}

else
{
echo ' <script> alert("sorry the user name or password is wrong"); </script>';
}


}

?>
</div>

</main>



<footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
</footer>

 </body>
</html>