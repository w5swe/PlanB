  
<!DOCTYPE html>

              <?php
session_start();
  include "connection.php";

?>
<html>
	<head>
		<link rel="stylesheet" href="hedfot.css">
        <link rel="stylesheet" href="Add&UpdateCake.css">
        <script src= "Add&UpdateCake.js"></script>

		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Update Cake Store </title>
	</head>
	<body>
	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> 

    <ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="adminlogin.php"> Login</a></li>
        <li><a href="ViewCakeAdminPage.php"> View Cake Shops</a></li>
        <li>Update Cake Shop</li> 
       </ul>

	</header>
<main>
 <?php 
              $id=$_GET['shop_id_ForUp'];
              $_SESSION['id']=$id;
            
            ?>
    <form id="AddCakeForm" name="AddCakeForm" action="editcakeshop.php" method ="POST">
        <fieldset id="fieldset">
         <legend>Update cake store</legend>
            <br>
            
            <?php 
           
            $updatesql="SELECT * FROM cake_shop WHERE id = $id";  
            $resultupsql= mysqli_query($connection, $updatesql);
            while($row = mysqli_fetch_assoc($resultupsql))
            {

          echo  "<label for='cakename'>Cake Store Name:</label>".
            '<input type="text" id ="cakename" value='.$row['cake_shop_name'].' name="cakename">'."<br>"."<br>" ;
           
          
            
           echo '<label for="serivce">Cake Type:</label>'.'<br>';
              if($row['cake_type']==1){
            echo '<input type="radio" id="T1" name="type" value="Vegetarians" checked >'.
            '<label for="ser1">Vegetarians</label>'.'<br>';
              }
              else 
              {
           echo '<input type="radio" id="T1" name="type" value="Vegetarians"  >'.
            '<label for="ser1">Vegetarians</label>'.'<br>';    
              }
                    
               if($row['cake_type']==2){     	
           echo  '<input type="radio" id="T2" name="type" value="Diabetics" checked>'.
            '<label for="ser2">Diabetics</label>'.'<br>';  
               }
            else 
              {
       echo  '<input type="radio" id="T2" name="type" value="Diabetics" >'.
            '<label for="ser2">Diabetics</label>'.'<br>'; 
              }
           	
              if($row['cake_type']==3){
           echo '<input type="radio" id="T3" name="type" value="Allergic" checked>'.
            '<label for="ser3">Allergic</label>'.'<br>';
              }
              else 
              {
               echo '<input type="radio" id="T3" name="type" value="Allergic">'.
            '<label for="ser3">Allergic</label>'.'<br>';   
              }
             if($row['cake_type']==4)
             {
           echo '<input type="radio" id="T4" name="type" value="Healthy" checked>'.
             '<label for="ser4">Healthy</label>'.'<br>'.'<br>';
             }
             else 
             {
                echo '<input type="radio" id="T4" name="type" value="Healthy" >'.
             '<label for="ser4">Healthy</label>'.'<br>'.'<br>';   
             }
            
            echo'<label for= "Discription">Add Discription </label>'. '<br>'.
            '<textarea id="Dis" name= "Discription" rows="10" cols="50" maxlength="300">'.$row['description'].'</textarea>'. '<br>'.'<br>';

            
            
            echo "<label>Select the  store's logo:".'<img src="logo/'.$row['logo_pic'].'" alt="'.$attachment1.'" style="width:15%;" />'."</label>";
            echo '<input type="file" id="attach" name="attachment" class="custom-file-input" multiple>'.'<br>'.'<br>';

                     } 
                    ?>
           
                     
             <input type="submit" value="Update" id="send" >
            
        </fieldset>
       </form>

    </main>

			
    <footer id="foot">
        <p>For Technical Problems please Contact us:</p>
        
        <pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany
        
        &copy; PLanB</pre>
         
        </footer>
        
                    </body>
                    </html>