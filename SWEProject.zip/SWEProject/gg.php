<?php 
session_start();

?>



//<?php
//$con = new PDO("mysql:host=localhost;dbname=PlanB",'root','root');
//
//if (isset($_POST["ssubmit"])) {
//	$str = $_POST["ssearch"];
//	$sth = $con->prepare("SELECT * FROM `cake_shop` WHERE cake_shop_name = '$str'");
//
//	$sth->setFetchMode(PDO:: FETCH_OBJ);
//	$sth -> execute();
//        
//        if($row = $sth->fetch())
//	{
//          $name = $row->name ;
//          $des= $row->description;
//          $logo = $row->logo_pic;
//          
//	}	
//		else{
//			echo "<script>alert('Sorry this cake shop is not avaliable!!'); window.location.href='viewcakeuserPage.php';</script>";
//		}
//
//
//}
// 
//?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="hedfot.css">
        <script src="Filter.js"></script> 
        <script src="Add&UpdateCake.js"></script>
        <link rel="stylesheet" href="Filter.css">
        <link rel="stylesheet" href="Add&UpdateCake.css">
        
       
		 <script src="raterecommended.js"></script>

		
		<title>View Cake Page User</title>
	</head>
	<body>
           <?php include "connection.php"; ?>
	<header class="hed">
	<span><img src="images/logo.png" alt="logo" id="logo"  width="200" height="200"></span>
	<span><a href="homepage.php"><img src="images/bakery-shop.png" alt="HomeIcon" id="home" width="50" height="50"></a></span> 

    <ul class="breadcrumb" id="hbc">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="userlogin.php"> Login</a></li>
        <li>View Cake Shops</li> 
       </ul>
 
	</header>
    
   


<!--<form method="post" >
    <label><img src="images/search.png" alt="search" id="search_icon"></label>
<input type="text" name="ssearch" id="searchtext" placeholder="What are you looking for?">
<input type="submit" name="ssubmit" value="SEARCH" id="Sbutton">
</form>-->

              

       <div>
<main>
  <div class="recommanded">
<div class="area">
<div class="good"><span>BEST CHOICE</span></div>
<img src="images/munchbakery.svg" alt="recommanded" id="best"  width="200" height="200">
<br>
<p id="cakename">BY PALET CAKE SHOP</p>
<br>
<br>
<button class="buttenbest" onclick="view(); return false;" >View shop</button>
</div>
	</div>
   
        <table id="cakeTable">
        
  <?php  
                $sql = "SELECT logo_pic ,cake_shop_name ,id FROM cake_shop";
                $result = mysqli_query($connection, $sql);

      while($row1=  mysqli_fetch_array($result)) {
      
            echo 
              "<tr><img class=\"img1\" src=\"logo/".$row1['logo_pic'].'" ></tr>'.
              "<tr><h2><nav class=\"shopname1\">".$row1['cake_shop_name']."</nav></h2></tr><br><br><br>".
             
              "<tr><a href='reviews.php?shop_id_ForViUser=".$row1['id']."'id=\"view1\">". "view</a></tr><br>";
          }?>
      
    </table>
 
</main>
           
           

<footer id="foot">
<p>For Technical Problems please Contact us:</p>

<pre><img src= "images/email2.png" width="20" height="20"> PlanB@gmail.com | <img src= "images/call2.png" width="20" height="20"> +966058477388 | <img src= "images/twitterR2.png" width="20" height="20"> @PlanBcompany

&copy; PLanB</pre>
 
</footer>

			</body>
			</html>